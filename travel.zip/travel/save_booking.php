<?php
// Database connection
$host = 'localhost';
$dbname = 'travel_db';
$username = 'root';
$password = '';

header('Content-Type: application/json');

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // JSON data receive
    $data = json_decode(file_get_contents('php://input'), true);
    
    // ONLY 5 fields insert - ja tomar table e ache
    $sql = "INSERT INTO bookings 
            (user_id, title, booking_date, price, phone, status, created_at) 
            VALUES 
            (:user_id, :title, :booking_date, :price, :phone, 'pending', NOW())";
    
    $stmt = $pdo->prepare($sql);
    
    $stmt->execute([
        ':user_id' => $data['user_id'],
        ':title' => $data['title'],
        ':booking_date' => $data['booking_date'],
        ':price' => $data['price'],
        ':phone' => $data['phone']
    ]);
    
    echo json_encode([
        'success' => true,
        'booking_id' => $pdo->lastInsertId()
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>