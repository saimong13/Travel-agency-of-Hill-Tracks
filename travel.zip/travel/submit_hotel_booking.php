<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'config/database.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Form theke data collect kora
    $fullname    = $_POST['fullName'] ?? '';
    $email       = $_POST['email'] ?? '';
    $phone       = $_POST['phone'] ?? '';
    $hotel_name  = $_POST['hotelName'] ?? 'Ocean View';
    $room_type   = $_POST['roomType'] ?? '';
    $check_in    = $_POST['checkIn'] ?? '';
    $check_out   = $_POST['checkOut'] ?? '';
    $guests      = $_POST['guests'] ?? 1;
    $rooms       = $_POST['rooms'] ?? 1; // Error line: Database e column thakte hobe
    $total_price = isset($_POST['total_price']) ? (float)$_POST['total_price'] : 0;
    $requests    = $_POST['requests'] ?? '';

    // SQL Query (Column name gulo database er sathe milte hobe)
    $sql = "INSERT INTO hotel_bookings (fullname, email, phone, hotel_name, room_type, check_in, check_out, guests, rooms, total_price, special_requests)
            VALUES ('$fullname', '$email', '$phone', '$hotel_name', '$room_type', '$check_in', '$check_out', '$guests', '$rooms', '$total_price', '$requests')";

    if ($conn->query($sql) === TRUE) {
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { background: #0f172a; color: white; display: flex; justify-content: center; align-items: center; height: 100vh; font-family: 'Inter', sans-serif; margin: 0; }
                .card { background: rgba(255,255,255,0.05); backdrop-filter: blur(20px); padding: 40px; border-radius: 24px; text-align: center; border: 1px solid rgba(255,255,255,0.1); box-shadow: 0 20px 40px rgba(0,0,0,0.4); }
                .icon { font-size: 50px; color: #10b981; margin-bottom: 20px; }
                .btn { background: #10b981; color: white; padding: 12px 30px; text-decoration: none; border-radius: 12px; display: inline-block; margin-top: 25px; transition: 0.3s; }
                .btn:hover { background: #059669; transform: translateY(-2px); }
            </style>
        </head>
        <body>
            <div class="card">
                <div class="icon">✔</div>
                <h2>Hotel Booking Received!</h2>
                <p>Total Stay Price: ৳ <?php echo number_format($total_price, 2); ?></p>
                <a href="hotel_booking.php" class="btn">Back to Form</a>
            </div>
        </body>
        </html>
        <?php
    } else {
        echo "Database Error: " . $conn->error;
    }
    $conn->close();
}
?>