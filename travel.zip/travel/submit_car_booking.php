<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'config/database.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Form theke data neya
    $fullname    = $_POST['fullName'] ?? 'Guest';
    $email       = $_POST['email'] ?? '';
    $phone       = $_POST['phone'] ?? '';
    $start_date  = $_POST['startDate'] ?? '';
    $end_date    = $_POST['endDate'] ?? '';
    $vehicles    = $_POST['vehicles'] ?? 1;
    $car_type    = $_POST['carType'] ?? 'Not Specified';
    $requests    = $_POST['requests'] ?? '';
    
    // Price-ke number-e convert kora jate Fatal Error na hoy
    $total_price = isset($_POST['total_price']) ? (float)$_POST['total_price'] : 0;

    $sql = "INSERT INTO car_bookings (fullname, email, phone, start_date, end_date, vehicles, car_type, requests, total_price)
            VALUES ('$fullname', '$email', '$phone', '$start_date', '$end_date', '$vehicles', '$car_type', '$requests', '$total_price')";

    if ($conn->query($sql) === TRUE) {
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { background: #0f172a; color: white; display: flex; justify-content: center; align-items: center; height: 100vh; font-family: sans-serif; margin: 0; }
                .card { background: rgba(255,255,255,0.05); backdrop-filter: blur(15px); padding: 40px; border-radius: 20px; text-align: center; border: 1px solid rgba(255,255,255,0.1); }
                .btn { background: #10b981; color: white; padding: 12px 25px; text-decoration: none; border-radius: 10px; display: inline-block; margin-top: 20px; }
            </style>
        </head>
        <body>
            <div class="card">
                <h1 style="color: #10b981;">✔ Car Booked!</h1>
                <p>Total Price Saved: ৳ <?php echo number_format($total_price, 2); ?></p>
                <a href="car_rental1.php" class="btn">Back to Form</a>
            </div>
        </body>
        </html>
        <?php
    } else {
        echo "Database Error: " . $conn->error;
    }
    $conn->close();
}
?>