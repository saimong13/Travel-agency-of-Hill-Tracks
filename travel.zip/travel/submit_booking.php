<?php
// Error reporting on koro jate blank page na ashe
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database configuration include koro
include 'config/database.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Form theke data collect kora
    $fullname  = $_POST['fullname'];
    $email     = $_POST['email'];
    $phone     = $_POST['phone'];
    $people    = $_POST['people'];
    $startdate = $_POST['startdate'];
    $enddate   = $_POST['enddate'];
    $requests  = $_POST['requests'];

    // SQL Query
    $sql = "INSERT INTO guide_bookings (fullname, email, phone, people, startdate, enddate, requests)
            VALUES ('$fullname', '$email', '$phone', '$people', '$startdate', '$enddate', '$requests')";

    if ($conn->query($sql) === TRUE) {
        // --- EKHANE PHP BONDHO KORE HTML SHURU ---
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <style>
                body {
                    margin: 0; padding: 0;
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background: #0f172a;
                    display: flex; justify-content: center; align-items: center;
                    height: 100vh; color: white;
                }
                .card {
                    background: rgba(255, 255, 255, 0.05);
                    backdrop-filter: blur(15px);
                    border: 1px solid rgba(255, 255, 255, 0.1);
                    padding: 40px; border-radius: 20px;
                    text-align: center; box-shadow: 0 10px 30px rgba(0,0,0,0.5);
                }
                .icon { font-size: 50px; color: #10b981; margin-bottom: 15px; }
                h2 { margin: 0; color: #fff; }
                p { color: #94a3b8; margin: 15px 0 25px; }
                .btn {
                    background: #10b981; color: white; text-decoration: none;
                    padding: 12px 30px; border-radius: 10px; font-weight: bold;
                    transition: 0.3s; display: inline-block;
                }
                .btn:hover { background: #059669; }
            </style>
        </head>
        <body>
            <div class="card">
                <div class="icon">✔</div>
                <h2>Booking Successful!</h2>
                <p>Thank you, your request has been recorded.</p>
                <a href="guide1.php" class="btn">Back to Home</a>
            </div>
        </body>
        </html>
        <?php
        // --- EKHANE PHP ABAR SHURU ---
    } else {
        echo "Database Error: " . $conn->error;
    }
    $conn->close();
} else {
    echo "Direct access allowed na! Form submit kore ashen.";
}
?>