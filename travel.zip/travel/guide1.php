
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Premium Booking Form</title>
  <style>
    body {
    font-family: 'Poppins', sans-serif;
    background: url("https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1470&q=80") no-repeat center center fixed;
    background-size: cover;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    }

    body::before {
    content: "";
    position: fixed;
    top: 0; left: 0;
    width: 100%; height: 100%;
    background: rgba(0,0,0,0.4); /* dark overlay */
    z-index: -1;
    }
    .booking-form {
      backdrop-filter: blur(12px);
      background: rgba(255, 255, 255, 0.15);
      border-radius: 16px;
      padding: 30px;
      width: 420px;
      box-shadow: 0 8px 25px rgba(0,0,0,0.3);
      color: #fff;
      position: relative;
    }

    /* Back icon button */
    .back-btn {
      position: absolute;
      top: 50px;
      left: 15px;
      background: rgba(255,255,255,0.25);
      border: none;
      border-radius: 50%;
      width: 40px;
      height: 40px;
      cursor: pointer;
      display: flex;
      justify-content: center;
      align-items: center;
      transition: all 0.3s ease;
      color: #fff;
      font-size: 20px;
    }
    .back-btn:hover {
      background: rgba(255,255,255,0.45);
      transform: scale(1.1);
    }

    .booking-form h2 {
      text-align: center;
      font-weight: 600;
      margin-bottom: 10px;
    }

    .booking-form p {
      text-align: center;
      font-size: 14px;
      margin-bottom: 20px;
    }

    .form-group {
      margin-bottom: 15px;
    }

    .form-group label {
      display: block;
      margin-bottom: 5px;
      font-weight: 500;
    }

    .form-group input, .form-group textarea {
      width: 100%;
      padding: 12px;
      border: none;
      border-radius: 8px;
      background: rgba(255,255,255,0.25);
      color: #fff;
      font-size: 14px;
      transition: all 0.3s ease;
    }

    .form-group input:focus, .form-group textarea:focus {
      outline: none;
      background: rgba(255,255,255,0.35);
      box-shadow: 0 0 8px rgba(255,255,255,0.6);
    }

    .form-group textarea {
      resize: none;
      height: 80px;
    }

    .btn-group {
      display: flex;
      justify-content: space-between;
      margin-top: 20px;
    }

    .btn {
      flex: 1;
      padding: 14px;
      margin: 0 5px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-size: 16px;
      font-weight: 600;
      transition: all 0.3s ease;
    }

    .btn-cancel {
      background: rgba(255,255,255,0.25);
      color: #fff;
    }
    .btn-cancel:hover {
      background: rgba(255,255,255,0.45);
      transform: scale(1.05);
    }

    .btn-submit {
      background: linear-gradient(135deg, #4ecdc4, #1a535c);
      color: #fff;
    }
    .btn-submit:hover {
      background: linear-gradient(135deg, #1a535c, #4ecdc4);
      transform: scale(1.08);
    }

    .note {
      font-size: 12px;
      margin-top: 15px;
      text-align: center;
      color: #eee;
    }
  </style>
</head>
<body>
  <div class="booking-form">
    <!-- Back icon button -->
    <button class="back-btn" onclick="history.back()">←</button>

    <h2>Book Tourist Guide</h2>
    <p>Guide: Bayzid Hasan — ৳ ৮০০/day</p>
    <form action="submit_booking.php" method="POST">
      <div class="form-group">
        <label>Full Name*</label>
        <input type="text" name="fullname" placeholder="" required>
      </div>
      <div class="form-group">
        <label>Email*</label>
        <input type="email" name="email" placeholder="" required>
      </div>
      <div class="form-group">
        <label>Phone Number*</label>
        <input type="tel" name="phone" placeholder="" required>
      </div>
      <div class="form-group">
        <label>Number of People</label>
        <input type="number" name="people" min="1" value="1">
      </div>
      <div class="form-group">
        <label>Start Date*</label>
        <input type="date" name="startdate" required>
      </div>
      <div class="form-group">
        <label>End Date*</label>
        <input type="date" name="enddate" required>
      </div>
      <div class="form-group">
        <label>Special Requests or Requirements</label>
        <textarea name="requests" placeholder="Any special requirements…"></textarea>
      </div>
      <div class="btn-group">
        <button type="reset" class="btn btn-cancel">Cancel</button>
        <button type="submit" class="btn btn-submit">Submit Booking Request</button>
      </div>
      <p class="note">By submitting this form, you agree to our terms and conditions.  
      We’ll send you a confirmation email with payment details and further instructions.</p>
    </form>
  </div>
</body>
</html>