// Elements
const authModal = document.getElementById('auth-modal');
const profileModal = document.getElementById('profile-modal');
const authButton = document.getElementById('auth-button');

const modalTitle = document.getElementById('modal-title');
const toggleAuth = document.getElementById('toggle-auth');
const submitBtn = document.getElementById('submit-btn');
const authForm = document.getElementById('auth-form');

const nameInput = document.getElementById('name');
const phoneInput = document.getElementById('phone');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');

// Profile Elements
const profileName = document.getElementById('profile-name');
const profileEmail = document.getElementById('profile-email');
const profileMemberSince = document.getElementById('profile-member-since');
const profileAvatar = document.getElementById('profile-avatar');
const profileNameCard = document.getElementById('profile-name-card');
const profilePhone = document.getElementById('profile-phone');
const bookingHistory = document.getElementById('booking-history');

// Edit Profile
const profileEdit = document.getElementById('profile-edit');
const editName = document.getElementById('edit-name');
const editPhone = document.getElementById('edit-phone');

let isLogin = true;

// Update Navigation
function updateNav() {
  const user = JSON.parse(localStorage.getItem('currentUser'));
  const authBtn = document.getElementById('auth-button');

  if(user) {
    const firstLetter = user.name.charAt(0).toUpperCase();
    authBtn.innerHTML = `<button class="profile-icon" title="${user.name}">${firstLetter}</button>`;
    document.querySelector('#auth-button button').addEventListener('click', ()=>{ showProfile(user); });
  } else {
    authBtn.innerHTML = `<button id="login-btn">Login</button>`;
    document.querySelector('#login-btn').addEventListener('click', ()=>{ authModal.classList.remove('hidden'); });
  }
}
updateNav();

// Toggle Login/Signup
toggleAuth.addEventListener('click', ()=>{
  isLogin = !isLogin;
  modalTitle.textContent = isLogin?'Login':'Signup';
  submitBtn.textContent = isLogin?'Login':'Signup';
  nameInput.classList.toggle('hidden', isLogin);
  phoneInput.classList.toggle('hidden', isLogin);
  toggleAuth.textContent = isLogin?'Signup':'Login';
});

// Form Submit
authForm.addEventListener('submit', (e)=>{
  e.preventDefault();
  const email = emailInput.value;
  const password = passwordInput.value;
  let users = JSON.parse(localStorage.getItem('users'))||[];

  if(isLogin){
    const user = users.find(u=>u.email===email && u.password===password);
    if(user){ localStorage.setItem('currentUser', JSON.stringify(user)); authModal.classList.add('hidden'); updateNav();}
    else alert('Invalid credentials');
  } else {
    const name = nameInput.value;
    const phone = phoneInput.value;
    if(users.find(u=>u.email===email)){ alert('User already exists'); return; }
    const newUser = { name, email, phone, password, memberSince: new Date().toLocaleDateString(), bookings: [] };
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    localStorage.setItem('currentUser', JSON.stringify(newUser));
    authModal.classList.add('hidden');
    updateNav();
  }
});

// Show Profile
function showProfile(user){
  profileModal.classList.remove('hidden');
  profileAvatar.textContent = user.name.charAt(0).toUpperCase();
  profileName.textContent = user.name;
  profileEmail.textContent = user.email;
  profileMemberSince.textContent = user.memberSince;
  profileNameCard.textContent = user.name;
  profilePhone.textContent = user.phone;
  bookingHistory.innerHTML = user.bookings.length?user.bookings.map(b=>`<div>${b}</div>`).join(''):'<p>No bookings yet</p>';

  profileEdit.classList.add('hidden');
  document.querySelector('.profile-info').classList.remove('hidden');
}

// Edit Profile
document.getElementById('edit-profile').addEventListener('click', ()=>{
  const user = JSON.parse(localStorage.getItem('currentUser'));
  editName.value = user.name;
  editPhone.value = user.phone;
  profileEdit.classList.remove('hidden');
  document.querySelector('.profile-info').classList.add('hidden');
});

// Save Profile
document.getElementById('save-profile').addEventListener('click', ()=>{
  let users = JSON.parse(localStorage.getItem('users'))||[];
  const user = JSON.parse(localStorage.getItem('currentUser'));
  user.name = editName.value;
  user.phone = editPhone.value;

  users = users.map(u=>u.email===user.email?user:u);
  localStorage.setItem('users', JSON.stringify(users));
  localStorage.setItem('currentUser', JSON.stringify(user));
  showProfile(user);
  updateNav();
});

// Cancel Edit
document.getElementById('cancel-edit').addEventListener('click', ()=>{
  profileEdit.classList.add('hidden');
  document.querySelector('.profile-info').classList.remove('hidden');
});

// Logout
document.getElementById('logout-btn').addEventListener('click', ()=>{
  localStorage.removeItem('currentUser');
  profileModal.classList.add('hidden');
  updateNav();
});

// Close Modals
document.querySelector('.close').addEventListener('click', ()=>authModal.classList.add('hidden'));
document.querySelector('.close-profile').addEventListener('click', ()=>profileModal.classList.add('hidden'));