<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Premium Car Rental</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: url('https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=1920&q=80') center/cover no-repeat fixed;
            position: relative;
            padding: 20px;
        }

        /* Dark overlay on background */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.55);
            z-index: -1;
        }

        /* Main Glassmorphism Card */
        .container {
            width: 100%;
            max-width: 480px;
            background: rgba(255, 255, 255, 0.12);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-radius: 24px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.4),
                        inset 0 0 0 1px rgba(255, 255, 255, 0.1);
            overflow: hidden;
            animation: slideUp 0.6s ease-out;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(40px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Header */
        .header {
            padding: 35px 30px 25px;
            text-align: center;
            position: relative;
        }

        .back-btn {
            position: absolute;
            top: 25px;
            left: 25px;
            width: 40px;
            height: 40px;
            background: rgba(255, 255, 255, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.25);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            font-size: 14px;
        }

        .back-btn:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: scale(1.1);
        }

        .header h1 {
            font-size: 28px;
            font-weight: 700;
            color: white;
            margin-bottom: 12px;
            letter-spacing: -0.5px;
        }

        .header-subtitle {
            color: rgba(255, 255, 255, 0.7);
            font-size: 15px;
            font-weight: 400;
            margin-bottom: 15px;
        }

        .price-tag {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(16, 185, 129, 0.25);
            border: 1px solid rgba(16, 185, 129, 0.4);
            padding: 8px 20px;
            border-radius: 50px;
            font-size: 16px;
            font-weight: 600;
            color: #6ee7b7;
            backdrop-filter: blur(10px);
        }

        .price-tag i {
            font-size: 14px;
        }

        /* Form Body */
        .form-body {
            padding: 0 30px 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-size: 14px;
            font-weight: 500;
            color: rgba(255, 255, 255, 0.85);
            margin-bottom: 8px;
        }

        .form-group label .required {
            color: #f87171;
            margin-left: 4px;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 14px 16px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 12px;
            font-size: 15px;
            font-family: 'Inter', sans-serif;
            color: white;
            transition: all 0.3s ease;
            outline: none;
        }

        .form-group input::placeholder,
        .form-group textarea::placeholder {
            color: rgba(255, 255, 255, 0.4);
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            background: rgba(255, 255, 255, 0.15);
            border-color: rgba(255, 255, 255, 0.4);
            box-shadow: 0 0 0 3px rgba(255, 255, 255, 0.1);
        }

        .form-group select {
            cursor: pointer;
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='white' viewBox='0 0 16 16'%3E%3Cpath d='M8 11L3 6h10l-5 5z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 16px center;
            padding-right: 40px;
        }

        .form-group select option {
            background: #1f2937;
            color: white;
        }

        .form-group textarea {
            min-height: 100px;
            resize: vertical;
        }

        /* Date input icon styling */
        input[type="date"]::-webkit-calendar-picker-indicator {
            filter: invert(1);
            opacity: 0.6;
            cursor: pointer;
        }

        /* Two column layout */
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        /* Price Box */
        .price-box {
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.15);
            border-radius: 16px;
            padding: 25px;
            margin: 25px 0;
            text-align: center;
            backdrop-filter: blur(10px);
        }

        .price-label {
            color: rgba(255, 255, 255, 0.6);
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 3px;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .price-amount {
            font-size: 42px;
            color: #6ee7b7;
            font-weight: 800;
            letter-spacing: -1px;
            text-shadow: 0 2px 10px rgba(16, 185, 129, 0.3);
            transition: all 0.3s ease;
        }

        .price-details {
            color: rgba(255, 255, 255, 0.5);
            font-size: 14px;
            margin-top: 8px;
            font-weight: 400;
        }

        /* Buttons */
        .btn-group {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-top: 10px;
        }

        .btn {
            padding: 16px;
            border: none;
            border-radius: 12px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            font-family: 'Inter', sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .btn-cancel {
            background: rgba(255, 255, 255, 0.1);
            color: rgba(255, 255, 255, 0.8);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .btn-cancel:hover {
            background: rgba(255, 255, 255, 0.2);
        }

        .btn-submit {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
            box-shadow: 0 10px 30px rgba(16, 185, 129, 0.3);
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 15px 40px rgba(16, 185, 129, 0.4);
        }

        .btn-submit:active {
            transform: translateY(0);
        }

        .btn-submit:disabled {
            opacity: 0.7;
            cursor: not-allowed;
        }

        /* Success Section */
        .success-section {
            display: none;
            text-align: center;
            padding: 50px 30px;
            animation: scaleIn 0.5s ease;
        }

        .success-section.active {
            display: block;
        }

        @keyframes scaleIn {
            from { transform: scale(0.9); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }

        .success-icon {
            width: 100px;
            height: 100px;
            background: linear-gradient(135deg, #10b981, #059669);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 25px;
            font-size: 50px;
            color: white;
            box-shadow: 0 20px 40px rgba(16, 185, 129, 0.4);
            animation: successPop 0.5s ease;
        }

        @keyframes successPop {
            0% { transform: scale(0); }
            60% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }

        .success-title {
            font-size: 28px;
            color: white;
            margin-bottom: 12px;
            font-weight: 700;
        }

        .success-text {
            color: rgba(255, 255, 255, 0.7);
            font-size: 16px;
            margin-bottom: 30px;
            line-height: 1.6;
        }

        .success-btn {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 14px 35px;
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            box-shadow: 0 10px 30px rgba(16, 185, 129, 0.3);
        }

        .success-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 15px 40px rgba(16, 185, 129, 0.4);
        }

        /* Responsive */
        @media (max-width: 480px) {
            .container {
                border-radius: 20px;
            }

            .header {
                padding: 30px 20px 20px;
            }

            .header h1 {
                font-size: 24px;
            }

            .form-body {
                padding: 0 20px 25px;
            }

            .form-row {
                grid-template-columns: 1fr;
                gap: 0;
            }

            .price-amount {
                font-size: 36px;
            }

            .btn-group {
                grid-template-columns: 1fr;
            }
        }
    </style>
<base target="_blank">
</head>
<body>
    <!-- Main Container -->
    <div class="container">
        <!-- Header -->
        <div class="header">
            <a href="home.html#rentals" class="back-btn">
                <i class="fas fa-arrow-left"></i>
            </a>
            <h1>Book Car Rental</h1>
            <p class="header-subtitle">Land Rover Defender 110 pickup</p>
            <div class="price-tag">
                <i class="fas fa-tag"></i>
                ৳ ৭৫০০/ day
            </div>
        </div>

        <!-- Form Section -->
        <div class="form-body" id="formSection">
            <form id="rentalForm" action="submit_car_booking.php" method="POST">
                <input type="hidden" name="total_price" id="hiddenTotalPrice" value="7500">
                <!-- Full Name -->
                <div class="form-group">
                    <label>Full Name <span class="required">*</span></label>
                    <input type="text" name="fullName" placeholder="Enter your full name" required>
                </div>

                <!-- Email -->
                <div class="form-group">
                    <label>Email <span class="required">*</span></label>
                    <input type="email" name="email" placeholder="your@email.com" required>
                </div>

                <!-- Phone -->
                <div class="form-group">
                    <label>Phone Number <span class="required">*</span></label>
                    <input type="tel" name="phone" placeholder="+880 1XXX-XXXXXX" required>
                </div>

                <!-- Two Column Row -->
                <div class="form-row">
                    <!-- Pick-up Date -->
                    <div class="form-group">
                        <label>Pick-up Date <span class="required">*</span></label>
                        <input type="date" name="startDate" required onchange="updatePrice()">
                    </div>

                    <!-- Return Date -->
                    <div class="form-group">
                        <label>Return Date <span class="required">*</span></label>
                        <input type="date" name="endDate" required onchange="updatePrice()">
                    </div>
                </div>

                <!-- Two Column Row -->
                <div class="form-row">
                    <!-- Vehicles -->
                    <div class="form-group">
                        <label>Number of Vehicles</label>
                        <select name="vehicles" onchange="updatePrice()">
                            <option value="1">1 Vehicle</option>
                            <option value="2">2 Vehicles</option>
                            <option value="3">3 Vehicles</option>
                            <option value="4">4 Vehicles</option>
                        </select>
                    </div>

                    <!-- Car Type -->
                    <div class="form-group">
                        <label>Car Type</label>
                        <select name="carType">
                            <option value="suv">7 seat</option>
                            <option value="sedan">8 seat</option>
                            <option value="sports">9 seat</option>
                        </select>
                    </div>
                </div>

                <!-- Special Requests -->
                <div class="form-group">
                    <label>Special Requests or Requirements</label>
                    <textarea name="requests" placeholder="Any special requirements (e.g., driver, pickup location, additional services)..." rows="3"></textarea>
                </div>

                <!-- Price Display -->
                <div class="price-box">
                    <div class="price-label">Estimated Total</div>
                    <div class="price-amount" id="totalPrice">৳ ৭৫০০</div>
                    <div class="price-details" id="priceDetails">for 1 day • 1 vehicle</div>
                </div>

                <!-- Buttons -->
                <div class="btn-group">
                    <button type="button" class="btn btn-cancel" onclick="window.location.href='home.html#rentals'">
                        Cancel
                    </button>
                    <button type="submit" class="btn btn-submit" id="submitBtn">
                        <span>Submit Booking</span>
                        <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
            </form>
        </div>

        <!-- Success Section -->
        <div class="success-section" id="successSection">
            <div class="success-icon">
                <i class="fas fa-check"></i>
            </div>
            <h2 class="success-title">Booking Confirmed!</h2>
            <p class="success-text">
                Thank you for choosing our premium service.<br>
                Our team will contact you within 24 hours.
            </p>
            <a href="home.html#rentals" class="success-btn">
                <i class="fas fa-arrow-left"></i>
                <span>Back to Rentals</span>
            </a>
        </div>
    </div>

    <script>
        const DAILY_PRICE = 7500৳;

        // Initialize date inputs
        document.addEventListener('DOMContentLoaded', function() {
            const today = new Date().toISOString().split('T')[0];
            document.querySelectorAll('input[type="date"]').forEach(input => {
                input.min = today;
            });
        });

        // Calculate Price
        function updatePrice() {
            const vehicles = parseInt(document.querySelector('select[name="vehicles"]').value) || 1;
            const startDate = document.querySelector('input[name="startDate"]').value;
            const endDate = document.querySelector('input[name="endDate"]').value;

            let days = 1;
            let details = 'for 1 day • 1 vehicle';

            if (startDate && endDate) {
                const start = new Date(startDate);
                const end = new Date(endDate);
                const diff = Math.ceil((end - start) / (1000 * 60 * 60 * 24));

                if (diff > 0) {
                    days = diff;
                    details = `for ${days} days • ${vehicles} vehicle${vehicles > 1 ? 's' : ''}`;
                }
            } else {
                details = `for 1 day • ${vehicles} vehicle${vehicles > 1 ? 's' : ''}`;
            }

            const total = DAILY_PRICE * vehicles * days;
            const priceElement = document.getElementById('totalPrice');

            // Animate price change
            priceElement.style.transform = 'scale(0.95)';
            priceElement.style.opacity = '0.7';

            setTimeout(() => {
                priceElement.textContent = '৳ ' + total.toLocaleString('bn-BD');
                priceElement.style.transform = 'scale(1)';
                priceElement.style.opacity = '1';
            }, 150);

            document.getElementById('priceDetails').textContent = details;
            // updatePrice() function er shesh e eita add koro
            document.getElementById('hiddenTotalPrice').value = total;
        }

        // Handle Submit
        async function handleSubmit(e) {
            e.preventDefault();

            const btn = document.getElementById('submitBtn');
            const originalContent = btn.innerHTML;

            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
            btn.disabled = true;

            // Simulate API call
            await new Promise(resolve => setTimeout(resolve, 2000));

            // Show success
            document.getElementById('formSection').style.display = 'none';
            document.getElementById('successSection').classList.add('active');
        }
    </script>
</body>
</html>