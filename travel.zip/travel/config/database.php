<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// ... uporer header gulo thakbe ...

$host = "localhost";
$username = "root"; 
$password = "";     
$database = "travel_db"; 

// Connection line ta eivabe hobe (Variable name gulo kheyal koro)
$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Database connection failed']));
}
?>