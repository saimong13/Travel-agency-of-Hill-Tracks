<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel Booking</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: url('https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1920') center/cover no-repeat fixed;
            position: relative;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.35);
            backdrop-filter: blur(3px);
        }

        .booking-card {
            position: relative;
            width: 90%;
            max-width: 420px;
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            padding: 28px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
            color: white;
        }

        .header {
            text-align: center;
            margin-bottom: 22px;
            position: relative;
        }

        .back-btn {
            position: absolute;
            left: -8px;
            top: -4px;
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.25);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            transition: all 0.3s;
        }

        .back-btn:hover {
            background: rgba(255, 255, 255, 0.4);
        }

        .header h1 {
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 8px;
            letter-spacing: 0.5px;
        }

        .header .subtitle {
            font-size: 14px;
            opacity: 0.9;
            font-weight: 400;
        }

        .form-group {
            margin-bottom: 16px;
        }

        .form-group label {
            display: block;
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 6px;
            opacity: 0.95;
        }

        .form-group label .required {
            color: #ff6b6b;
            margin-left: 2px;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 13px 14px;
            border: none;
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.25);
            color: white;
            font-size: 14px;
            outline: none;
            transition: all 0.3s;
            border: 1px solid transparent;
        }

        .form-group input::placeholder,
        .form-group textarea::placeholder {
            color: rgba(255, 255, 255, 0.6);
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            background: rgba(255, 255, 255, 0.35);
            border-color: rgba(255, 255, 255, 0.5);
        }

        input[type="date"]::-webkit-calendar-picker-indicator {
            filter: invert(1);
            cursor: pointer;
        }

        .row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
        }

        .buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-top: 22px;
        }

        .btn {
            padding: 14px;
            border: none;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }

        .btn-cancel {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .btn-cancel:hover {
            background: rgba(255, 255, 255, 0.35);
        }

        .btn-submit {
            background: linear-gradient(135deg, #2dd4bf, #0d9488);
            color: white;
            box-shadow: 0 4px 15px rgba(13, 148, 136, 0.4);
        }

        .btn-submit:hover {
            background: linear-gradient(135deg, #5eead4, #14b8a6);
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(13, 148, 136, 0.5);
        }

        .footer-text {
            text-align: center;
            font-size: 11px;
            opacity: 0.85;
            margin-top: 18px;
            line-height: 1.5;
        }

        .price-tag {
            display: inline-block;
            background: rgba(45, 212, 191, 0.25);
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            margin-top: 6px;
            border: 1px solid rgba(45, 212, 191, 0.4);
        }

        @media (max-width: 480px) {
            .booking-card {
                width: 95%;
                padding: 20px;
            }
            
            .row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

    <div class="booking-card">
        <div class="header">
            <button class="back-btn" onclick="history.back()">←</button>
            <h1>Book Hotel Room</h1>
            <div class="subtitle">
                Hotel: Hotel Night Heaven
                <div class="price-tag">৳ ২০০০ / night</div>
            </div>
        </div>

        <form id="hotelBookingForm" action="submit_hotel_booking.php" method="POST">
    
    <input type="hidden" name="total_price" id="hiddenTotalPrice" value="2000">
            <div class="form-group">
                <label>Full Name <span class="required">*</span></label>
                <input type="text" name="fullName" placeholder="Enter your full name" required>
            </div>

            <div class="form-group">
                <label>Email <span class="required">*</span></label>
                <input type="email" name="email" placeholder="your@email.com" required>
            </div>

            <div class="form-group">
                <label>Phone Number <span class="required">*</span></label>
                <input type="tel" name="phone" placeholder="+880 1XXX-XXXXXX" required>
            </div>

            <div class="row">
                <div class="form-group">
                    <label>Check-in Date <span class="required">*</span></label>
                    <input type="date" name="checkIn" required>
                </div>
                <div class="form-group">
                    <label>Check-out Date <span class="required">*</span></label>
                    <input type="date" name="checkOut" required>
                </div>
            </div>

            <div class="row">
                <div class="form-group">
                    <label>Number of Guests</label>
                    <select name="guests">
                        <option value="1">1 Guest</option>
                        <option value="2" selected>2 Guests</option>
                        <option value="3">3 Guests</option>
                        <option value="4">4 Guests</option>
                        <option value="5">5 Guests</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Room Type</label>
                    <select name="roomType">
                        <option value="standard">Standard Room</option>
                        <option value="deluxe" selected>Deluxe Suite</option>
                        <option value="suite">Executive Suite</option>
                        <option value="presidential">Presidential Suite</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label>Special Requests or Requirements</label>
                <textarea name="requests" rows="3" placeholder="Any special requirements (e.g., extra bed, late check-in, sea view)..."></textarea>
            </div>

            <div class="buttons">
                <button type="button" class="btn btn-cancel" onclick="history.back()">Cancel</button>
                <button type="submit" class="btn btn-submit">Submit Booking Request</button>
            </div>
        </form>

        <div class="footer-text">
            By submitting this form, you agree to our terms and conditions.<br>
            We'll send you a confirmation email with payment details and booking reference.
        </div>
    </div>

    <script>
        const today = new Date().toISOString().split('T')[0];
        document.querySelector('input[name="checkIn"]').min = today;
        document.querySelector('input[name="checkOut"]').min = today;

        document.querySelector('input[name="checkIn"]').addEventListener('change', function() {
            document.querySelector('input[name="checkOut"]').min = this.value;
        });

        const PER_NIGHT_PRICE = 5000; // Tomar ichchamoto dam daw

        function calculateHotelPrice() {
            const checkIn = document.querySelector('input[name="checkIn"]').value;
            const checkOut = document.querySelector('input[name="checkOut"]').value;
            const rooms = parseInt(document.querySelector('select[name="rooms"]').value) || 1;

        if (checkIn && checkOut) {
            const start = new Date(checkIn);
            const end = new Date(checkOut);
            const diffTime = Math.abs(end - start);
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) || 1;

            const total = PER_NIGHT_PRICE * rooms * diffDays;
            document.getElementById('hiddenTotalPrice').value = total;
            
        }
    }

// Check-in ba check-out change hole price update hobe
document.querySelector('input[name="checkIn"]').addEventListener('change', calculateHotelPrice);
document.querySelector('input[name="checkOut"]').addEventListener('change', calculateHotelPrice);
document.querySelector('select[name="rooms"]').addEventListener('change', calculateHotelPrice);
        document.getElementById('hotelBookingForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const data = Object.fromEntries(formData);
            
            if (new Date(data.checkOut) <= new Date(data.checkIn)) {
                alert('Check-out date must be after check-in date!');
                return;
            }

            console.log('Hotel Booking Data:', data);
            alert('Booking request submitted successfully!\n\nCheck browser console for the data object.');
        });
    </script>

</body>
</html>